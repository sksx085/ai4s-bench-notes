# AI4S 出题工作台 0.2.0

核对下载页面的 SHA-256 后解压。将下列第一条命令的路径换成包含 .agents 和 plugins 的解压目录。

    codex plugin marketplace add "/实际路径/ai4s-workbench-marketplace-0.2.0"
    codex plugin add ai4s-task-workbench@ai4s-bench-notes

新开 Codex 会话，选择 AI4S 出题工作台。插件内置的 Skill 提供「问题、解答、约束」的题面工具。运行本地脚本需要 Python 3.9 或更新版本。

完整命令说明在 plugins/ai4s-task-workbench/skills/ai4s-task-workbench/references/contract.md。
