#!/usr/bin/env python3
"""Offline, standard-library-only installer for the adjacent verified skill kit.

Protocol: manifest.json has exactly name, version, and files keys. files maps
every kit file except manifest.json to a lowercase SHA-256 digest. Only
install.py, INSTALL.txt, and files beneath NAME/ may be present. Directories
must be implied by these paths. Installed files are exactly the NAME/ subtree.
The manifest detects accidental damage; it is not an authenticity signature.
"""

from __future__ import annotations

import argparse
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import sys
import tempfile
import unicodedata
from datetime import datetime, timezone
import uuid

NAME = "ai4s-challenge-design"
VERSION = "0.1.0"
RESERVED = {"CON", "PRN", "AUX", "NUL"} | {
    f"{prefix}{i}" for prefix in ("COM", "LPT") for i in range(1, 10)
}


class InstallError(Exception):
    """A safe, actionable refusal or an installation error."""


def same_identity(left: os.stat_result, right: os.stat_result) -> bool:
    return (left.st_dev, left.st_ino) == (right.st_dev, right.st_ino)


def is_link_or_reparse(info: os.stat_result) -> bool:
    return stat.S_ISLNK(info.st_mode) or bool(
        getattr(info, "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    )


def read_regular(path: Path) -> bytes:
    """Reject links/devices and detect ordinary replacement during reading."""
    before = path.lstat()
    if is_link_or_reparse(before) or not stat.S_ISREG(before.st_mode):
        raise InstallError(f"不是普通文件，或为符号链接：{path}")
    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(path, flags)
    with os.fdopen(fd, "rb") as stream:
        opened = os.fstat(stream.fileno())
        if is_link_or_reparse(opened) or not stat.S_ISREG(opened.st_mode) or not same_identity(before, opened):
            raise InstallError(f"读取期间文件被替换：{path}")
        data = stream.read()
        after = os.fstat(stream.fileno())
    final = path.lstat()
    if (
        not same_identity(opened, final)
        or is_link_or_reparse(final)
        or not stat.S_ISREG(final.st_mode)
        or (opened.st_size, opened.st_mtime_ns, opened.st_ctime_ns)
        != (after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    ):
        raise InstallError(f"读取期间文件已变化：{path}")
    return data


def portable_path(value: object) -> str:
    if not isinstance(value, str) or not value:
        raise InstallError("清单路径必须为非空字符串")
    parts = value.split("/")
    if PurePosixPath(value).is_absolute() or any(
        part in ("", ".", "..")
        or part.endswith((".", " "))
        or part.split(".")[0].upper() in RESERVED
        or any(ord(char) < 32 or ord(char) == 127 or char in '\\:*?"<>|' for char in part)
        for part in parts
    ):
        raise InstallError(f"不安全或不可移植的清单路径：{value!r}")
    return value


def no_duplicate_keys(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise InstallError(f"JSON 包含重复键：{key!r}")
        result[key] = value
    return result


def implied_directories(paths: set[str]) -> set[str]:
    return {
        str(parent)
        for path in paths
        for parent in PurePosixPath(path).parents
        if str(parent) != "."
    }


def real_directory(path: Path) -> os.stat_result:
    info = path.lstat()
    if is_link_or_reparse(info) or not stat.S_ISDIR(info.st_mode):
        raise InstallError(f"目录不存在、不是目录或为符号链接：{path}")
    return info


def inventory(root: Path) -> tuple[dict[str, bytes], set[str]]:
    """Read only regular files; do not traverse any symlink."""
    real_directory(root)
    files: dict[str, bytes] = {}
    directories: set[str] = set()

    def visit(directory: Path) -> None:
        before = real_directory(directory)
        with os.scandir(directory) as entries:
            for entry in sorted(entries, key=lambda item: item.name):
                path = directory / entry.name
                relative = path.relative_to(root).as_posix()
                portable_path(relative)
                info = entry.stat(follow_symlinks=False)
                if is_link_or_reparse(info):
                    raise InstallError(f"拒绝符号链接或目录重解析点：{path}")
                if stat.S_ISDIR(info.st_mode):
                    directories.add(relative)
                    visit(path)
                elif stat.S_ISREG(info.st_mode):
                    files[relative] = read_regular(path)
                else:
                    raise InstallError(f"拒绝符号链接或特殊文件：{path}")
        if not same_identity(before, real_directory(directory)):
            raise InstallError(f"扫描期间目录被替换：{directory}")

    visit(root)
    return files, directories


def verify_kit(root: Path) -> dict[str, bytes]:
    """Verify exact kit inventory and retain verified payload bytes in memory."""
    manifest_bytes = read_regular(root / "manifest.json")
    try:
        manifest = json.loads(manifest_bytes.decode("utf-8"), object_pairs_hook=no_duplicate_keys)
    except (UnicodeError, ValueError) as exc:
        raise InstallError(f"manifest.json 不是有效的 UTF-8 JSON：{exc}") from exc
    if not isinstance(manifest, dict) or set(manifest) != {"name", "version", "files"}:
        raise InstallError("清单必须且只能包含 name、version、files")
    if manifest["name"] != NAME or manifest["version"] != VERSION:
        raise InstallError(f"清单必须对应 {NAME} {VERSION}")
    expected = manifest["files"]
    if not isinstance(expected, dict) or not expected:
        raise InstallError("清单 files 必须为非空对象")
    for key, digest in expected.items():
        portable_path(key)
        if key not in {"install.py", "INSTALL.txt"} and not key.startswith(NAME + "/"):
            raise InstallError(f"清单包含分发范围外的路径：{key}")
        if not isinstance(digest, str) or re.fullmatch(r"[0-9a-f]{64}", digest) is None:
            raise InstallError(f"无效的 SHA-256：{key}")
    required = {"install.py", "INSTALL.txt", f"{NAME}/SKILL.md"}
    if not required.issubset(expected):
        raise InstallError("清单缺少 install.py、INSTALL.txt 或技能 SKILL.md")
    expected_dirs = implied_directories(set(expected))
    all_paths = set(expected) | expected_dirs | {"manifest.json"}
    folded = [unicodedata.normalize("NFC", path).casefold() for path in all_paths]
    if len(folded) != len(set(folded)) or set(expected) & expected_dirs:
        raise InstallError("清单存在大小写路径冲突或文件与目录冲突")
    actual, actual_dirs = inventory(root)
    if set(actual) != set(expected) | {"manifest.json"} or actual_dirs != expected_dirs:
        missing = sorted(set(expected) - set(actual))
        extra = sorted((set(actual) - set(expected) - {"manifest.json"}) | (actual_dirs - expected_dirs))
        raise InstallError(f"文件清单不一致；缺少：{missing}；多余：{extra}")
    if actual["manifest.json"] != manifest_bytes:
        raise InstallError("验证期间 manifest.json 已变化")
    for relative, digest in expected.items():
        if hashlib.sha256(actual[relative]).hexdigest() != digest:
            raise InstallError(f"SHA-256 校验失败：{relative}")
    return {
        path.removeprefix(NAME + "/"): data
        for path, data in actual.items()
        if path.startswith(NAME + "/")
    }


def within(path: Path, parent: Path) -> bool:
    return path == parent or parent in path.parents


def target_path(raw: Path) -> Path:
    """Accept real ancestor aliases, but never follow the selected root itself."""
    absolute = Path(os.path.abspath(raw.expanduser()))
    root = absolute.parent.resolve() / absolute.name
    if root == root.parent:
        raise InstallError("技能目录不能是文件系统根目录")
    if root.exists() or root.is_symlink():
        real_directory(root)
    return root


@contextmanager
def install_lock(skills: Path):
    suffix = hashlib.sha256(str(skills).encode("utf-8")).hexdigest()[:16]
    path = skills.parent / f".{NAME}-{suffix}.install.lock"
    try:
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY | getattr(os, "O_NOFOLLOW", 0), 0o600)
    except FileExistsError as exc:
        raise InstallError(f"存在安装锁；确认无安装进程后再清理：{path}") from exc
    identity = os.fstat(fd)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            stream.write(f"pid={os.getpid()}\n")
        yield
    finally:
        try:
            if same_identity(identity, path.lstat()):
                path.unlink()
        except FileNotFoundError:
            pass


def install_payload(kit: Path, payload: dict[str, bytes], raw_skills: Path, replace: bool) -> tuple[str, Path, Path | None]:
    skills = target_path(raw_skills)
    backup_root = skills.parent / "skill-backups"
    if within(backup_root, skills):
        raise InstallError("备份目录必须位于技能加载目录之外；请使用其他 --skills-dir")
    if within(skills, kit) or within(kit, skills) or within(kit, backup_root) or within(backup_root, kit):
        raise InstallError("分发包、技能目录和备份目录不可重叠")
    skills.mkdir(parents=True, exist_ok=True)
    root_identity = real_directory(skills)
    destination = skills / NAME
    with install_lock(skills):
        existed = destination.exists() or destination.is_symlink()
        old_identity = None
        if existed:
            old_identity = real_directory(destination)
            installed, dirs = inventory(destination)
            if installed == payload and dirs == implied_directories(set(payload)):
                return "unchanged", destination, None
            if not replace:
                raise InstallError(f"目标已有不同内容；未覆盖。检查后可使用 --replace：{destination}")
        backup = None
        with tempfile.TemporaryDirectory(prefix=f".{NAME}-stage-", dir=skills.parent) as temp:
            staged = Path(temp) / NAME
            staged.mkdir(mode=0o755)
            for relative, data in sorted(payload.items()):
                path = staged.joinpath(*PurePosixPath(relative).parts)
                path.parent.mkdir(parents=True, exist_ok=True)
                with path.open("xb") as stream:
                    stream.write(data)
                    stream.flush()
                    os.fsync(stream.fileno())
                path.chmod(0o644)
            staged_files, staged_dirs = inventory(staged)
            if staged_files != payload or staged_dirs != implied_directories(set(payload)):
                raise InstallError("暂存文件复核失败")
            if not same_identity(root_identity, real_directory(skills)):
                raise InstallError("安装期间技能目录被替换")
            if existed:
                if not same_identity(old_identity, real_directory(destination)):
                    raise InstallError("安装期间原技能目录被替换")
                backup_root.mkdir(mode=0o700, exist_ok=True)
                real_directory(backup_root)
                stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
                backup = backup_root / f"{NAME}-{stamp}-{uuid.uuid4().hex}"
                if backup.exists() or backup.is_symlink():
                    raise InstallError(f"备份目标已存在：{backup}")
            try:
                if backup is not None:
                    destination.rename(backup)
                if destination.exists() or destination.is_symlink():
                    raise InstallError("安装期间目标已出现；未覆盖")
                staged.rename(destination)
            except BaseException as exc:
                if backup is not None and (backup.exists() or backup.is_symlink()):
                    try:
                        if not same_identity(root_identity, real_directory(skills)):
                            raise InstallError("技能目录被替换")
                        if not same_identity(old_identity, real_directory(backup)):
                            raise InstallError("备份目录被替换")
                        if destination.exists() or destination.is_symlink():
                            raise InstallError("目标路径被其他进程占用")
                        backup.rename(destination)
                    except BaseException as rollback_error:
                        raise InstallError(f"安装失败且无法自动恢复；旧技能完整保留于 {backup}；恢复错误：{rollback_error}") from exc
                raise
        return "installed", destination, backup


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=f"离线校验并安装 {NAME} {VERSION}；Python 3.11+")
    parser.add_argument("--check", action="store_true", help="只验证分发包，不访问或修改安装目录")
    parser.add_argument("--skills-dir", type=Path, help="指定技能目录（默认 $CODEX_HOME/skills 或 ~/.codex/skills）")
    parser.add_argument("--replace", action="store_true", help="将已有的不同内容备份到同级 skill-backups 后替换")
    args = parser.parse_args(argv)
    if sys.version_info < (3, 11):
        parser.error("需要 Python 3.11 或更高版本")
    try:
        script = Path(os.path.abspath(__file__))
        if script.is_symlink():
            raise InstallError("请运行分发包内的真实 install.py，不能使用符号链接")
        kit = script.parent.resolve()
        payload = verify_kit(kit)
        if args.check:
            print(f"校验通过：{NAME} {VERSION}；{len(payload)} 个技能文件。未执行安装。")
            return 0
        codex_home = os.environ.get("CODEX_HOME")
        default = Path(codex_home).expanduser() / "skills" if codex_home else Path.home() / ".codex" / "skills"
        status, destination, backup = install_payload(kit, payload, args.skills_dir or default, args.replace)
        if status == "unchanged":
            print(f"内容一致，无需安装：{destination}")
        else:
            print(f"已安装 {NAME} {VERSION}：{destination}")
            if backup is not None:
                print(f"旧内容备份：{backup}")
            print("请开启新的 Codex 会话，并使用 $ai4s-challenge-design 调用。")
        return 0
    except (InstallError, OSError) as exc:
        print(f"错误：{exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
