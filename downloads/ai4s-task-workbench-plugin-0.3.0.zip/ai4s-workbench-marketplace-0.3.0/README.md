# AI4S 出题工作台 0.3.0

核对下载页面的 SHA-256 后解压。将命令中的路径替换为包含 `.agents/` 和 `plugins/` 的解压目录。

    codex plugin marketplace add "/实际路径/ai4s-workbench-marketplace-0.3.0" && codex plugin add ai4s-task-workbench@ai4s-bench-notes

从旧 ZIP 升级时，先用 `codex plugin marketplace remove ai4s-bench-notes` 移除旧目录的登记，再运行上面的安装命令。

打开新 Codex 会话，选择 AI4S 出题工作台。运行本地脚本需要 Python 3.9 或更新版本。

可生成出题骨架，也可精简已有题面。基本结构包括问题、输入、输出、约束和精度。计分或排名时加上评分。

命令和字段说明在 `plugins/ai4s-task-workbench/skills/ai4s-task-workbench/references/contract.md`。
