#!/usr/bin/env python3
"""Fit the public Dy support ladders and write predictions.csv.

Rule, fit on SUP-01..SUP-21 only:

    log(kd_cm1_k) = a_k + b_k * log(g_trans + 0.003) + c_k * sum(R^{-3})

R is the distance in angstrom from Dy to a non-hydrogen atom inside 3.2 A.
The 95% interval on kd_cm1_1 is the equal-tailed Student-t prediction
interval on that log scale (df = n - 3), exponentiated.
"""

from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EPS = 0.003
CUTOFF = 3.2
# Two-tailed 95% critical value of Student's t with 18 degrees of freedom.
T_18 = 2.100922

LEVELS = list(range(1, 8))
FIELDS = [
    "case_id",
    "kd_cm1_1",
    "lower95_cm1",
    "upper95_cm1",
    "kd_cm1_2",
    "kd_cm1_3",
    "kd_cm1_4",
    "kd_cm1_5",
    "kd_cm1_6",
    "kd_cm1_7",
]


def load_rows(name):
    with (ROOT / name).open(newline="") as handle:
        return list(csv.DictReader(handle))


def parse_counts(text):
    text = text.strip().strip("{}")
    if not text:
        return {}
    counts = {}
    for part in text.split(","):
        element, number = part.split(":")
        counts[element.strip()] = int(number)
    return counts


def donor_distances(case_id):
    lines = (ROOT / "structures" / f"{case_id}.xyz").read_text().splitlines()
    n_atoms = int(lines[0].strip())
    elements = []
    coords = []
    for line in lines[2 : 2 + n_atoms]:
        parts = line.split()
        elements.append(parts[0])
        coords.append(tuple(float(v) for v in parts[1:4]))
    origin = coords[elements.index("Dy")]
    distances = []
    for element, xyz in zip(elements, coords):
        if element in ("Dy", "H"):
            continue
        dx = xyz[0] - origin[0]
        dy = xyz[1] - origin[1]
        dz = xyz[2] - origin[2]
        dist = math.sqrt(dx * dx + dy * dy + dz * dz)
        if 0.4 < dist <= CUTOFF:
            distances.append((element, dist))
    return distances


def distance_sum(case_id):
    return sum(dist ** -3 for _, dist in donor_distances(case_id))


def features(case_id, g_trans, strength):
    return [1.0, math.log(g_trans + EPS), strength]


def solve_ols(design, targets):
    width = len(design[0])
    xtx = [[0.0] * width for _ in range(width)]
    xty = [0.0] * width
    for row, target in zip(design, targets):
        for i in range(width):
            xty[i] += row[i] * target
            for j in range(width):
                xtx[i][j] += row[i] * row[j]
    matrix = [
        xtx[i][:] + [1.0 if i == j else 0.0 for j in range(width)] + [xty[i]]
        for i in range(width)
    ]
    for col in range(width):
        pivot = max(range(col, width), key=lambda row: abs(matrix[row][col]))
        matrix[col], matrix[pivot] = matrix[pivot], matrix[col]
        scale = matrix[col][col]
        if abs(scale) < 1e-14:
            raise RuntimeError("singular crystal-field design matrix")
        for col2 in range(len(matrix[col])):
            matrix[col][col2] /= scale
        for row in range(width):
            if row == col:
                continue
            factor = matrix[row][col]
            for col2 in range(len(matrix[row])):
                matrix[row][col2] -= factor * matrix[col][col2]
    beta = [matrix[i][-1] for i in range(width)]
    inverse = [matrix[i][width : 2 * width] for i in range(width)]
    return beta, inverse


def fit_support(support):
    strengths = {row["case_id"]: distance_sum(row["case_id"]) for row in support}
    design = [
        features(row["case_id"], float(row["g_trans"]), strengths[row["case_id"]])
        for row in support
    ]
    betas = []
    residual_variance = None
    inverse = None
    for level in LEVELS:
        targets = [math.log(float(row[f"kd_cm1_{level}"])) for row in support]
        beta, inv = solve_ols(design, targets)
        betas.append(beta)
        if level == 1:
            residual_sum = 0.0
            for row, target in zip(design, targets):
                mean = sum(coef * value for coef, value in zip(beta, row))
                residual_sum += (target - mean) ** 2
            residual_variance = residual_sum / (len(support) - len(beta))
            inverse = inv
    return betas, inverse, residual_variance, strengths


def predict_levels(betas, g_trans, strength):
    row = features("", g_trans, strength)
    levels = []
    for beta in betas:
        value = math.exp(sum(coef * item for coef, item in zip(beta, row)))
        if levels and value < levels[-1]:
            value = levels[-1]
        levels.append(value)
    return levels


def interval_kd1(beta, inverse, variance, g_trans, strength):
    row = features("", g_trans, strength)
    mean = sum(coef * item for coef, item in zip(beta, row))
    quadratic = [
        sum(inverse[i][j] * row[j] for j in range(3)) for i in range(3)
    ]
    leverage = sum(row[i] * quadratic[i] for i in range(3))
    scale = math.sqrt(variance * (1.0 + leverage))
    return math.exp(mean - T_18 * scale), math.exp(mean + T_18 * scale)


def tenth(value):
    return round(value + 1e-12, 1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    support = load_rows("support.csv")
    cases = load_rows("cases.csv")
    for row in support + cases:
        counted = {}
        for element, _dist in donor_distances(row["case_id"]):
            counted[element] = counted.get(element, 0) + 1
        stated = parse_counts(row["neighbor_counts"])
        if counted != stated:
            raise SystemExit(f"neighbor mismatch for {row['case_id']}: {counted} vs {stated}")
    betas, inverse, variance, _strengths = fit_support(support)
    out_path = args.out
    with out_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        for row in cases:
            strength = distance_sum(row["case_id"])
            g_trans = float(row["g_trans"])
            levels = predict_levels(betas, g_trans, strength)
            low, high = interval_kd1(betas[0], inverse, variance, g_trans, strength)
            point = tenth(levels[0])
            low, high = tenth(low), tenth(high)
            low = min(low, point)
            high = max(high, point)
            values = [tenth(level) for level in levels]
            values[0] = point
            for index in range(1, 7):
                if values[index] < values[index - 1]:
                    values[index] = values[index - 1]
            payload = {
                "case_id": row["case_id"],
                "lower95_cm1": f"{low:.1f}",
                "upper95_cm1": f"{high:.1f}",
            }
            for index, level in enumerate(values, start=1):
                payload[f"kd_cm1_{index}"] = f"{level:.1f}"
            writer.writerow(payload)
    print(f"wrote {out_path.name}")


if __name__ == "__main__":
    main()
