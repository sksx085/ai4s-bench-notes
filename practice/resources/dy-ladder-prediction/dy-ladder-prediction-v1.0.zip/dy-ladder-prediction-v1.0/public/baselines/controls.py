"""Reproduce three offline controls using only the public challenge inputs."""

from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STRUCTURES = ROOT / "structures"
CUTOFF_A = 3.2
ELEMENTS = ("O", "N", "C", "F", "Cl", "Br", "I", "S", "P")
ALPHAS = (0.01, 0.1, 1.0, 10.0, 100.0, 1000.0, 10000.0)
LEVELS = tuple(range(1, 8))


def parse_xyz(path: Path):
    lines = path.read_text().splitlines()
    n = int(lines[0])
    atoms = []
    for line in lines[2 : 2 + n]:
        element, x, y, z = line.split()[:4]
        atoms.append((element, float(x), float(y), float(z)))
    return atoms


def features(case_id: str):
    atoms = parse_xyz(STRUCTURES / f"{case_id}.xyz")
    dysprosium = next(atom for atom in atoms if atom[0] == "Dy")
    donors = []
    for atom in atoms:
        if atom[0] in ("H", "Dy"):
            continue
        distance = math.dist(dysprosium[1:], atom[1:])
        if distance <= CUTOFF_A:
            donors.append((atom[0], distance))
    counts = {element: 0 for element in ELEMENTS}
    other = 0
    distances = []
    for element, distance in donors:
        distances.append(distance)
        if element in counts:
            counts[element] += 1
        else:
            other += 1
    mean = sum(distances) / len(distances)
    variance = sum((item - mean) ** 2 for item in distances) / len(distances)
    return [
        float(len(donors)),
        *[float(counts[element]) for element in ELEMENTS],
        float(other),
        min(distances),
        mean,
        max(distances),
        math.sqrt(variance),
    ]


def read_rows(path: Path):
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle))


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def solve(matrix, vector):
    size = len(vector)
    aug = [row[:] + [vector[i]] for i, row in enumerate(matrix)]
    for col in range(size):
        pivot = max(range(col, size), key=lambda row: abs(aug[row][col]))
        aug[col], aug[pivot] = aug[pivot], aug[col]
        scale = aug[col][col]
        if abs(scale) < 1e-12:
            raise ZeroDivisionError("singular ridge system")
        for j in range(col, size + 1):
            aug[col][j] /= scale
        for row in range(size):
            if row == col:
                continue
            factor = aug[row][col]
            for j in range(col, size + 1):
                aug[row][j] -= factor * aug[col][j]
    return [aug[i][size] for i in range(size)]


def standardize(rows, mean=None, scale=None):
    width = len(rows[0])
    if mean is None:
        mean = [sum(row[j] for row in rows) / len(rows) for j in range(width)]
    if scale is None:
        scale = []
        for j in range(width):
            var = sum((row[j] - mean[j]) ** 2 for row in rows) / len(rows)
            scale.append(math.sqrt(var) if var > 1e-12 else 1.0)
    out = []
    for row in rows:
        out.append([(row[j] - mean[j]) / scale[j] for j in range(width)])
    return out, mean, scale


def fit_ridge(x_rows, y, alpha):
    n = len(y)
    p = len(x_rows[0])
    # Column 0 is an unpenalized intercept.
    design = [[1.0, *row] for row in x_rows]
    xtx = [[0.0] * (p + 1) for _ in range(p + 1)]
    xty = [0.0] * (p + 1)
    for i in range(n):
        for a in range(p + 1):
            xty[a] += design[i][a] * y[i]
            for b in range(p + 1):
                xtx[a][b] += design[i][a] * design[i][b]
    for j in range(1, p + 1):
        xtx[j][j] += alpha
    return solve(xtx, xty)


def predict_row(coef, row):
    return coef[0] + dot(coef[1:], row)


def loo_ridge(raw, y, alpha):
    errors = []
    predictions = []
    for hold in range(len(y)):
        train = [raw[i] for i in range(len(y)) if i != hold]
        target = [y[i] for i in range(len(y)) if i != hold]
        scaled, mean, scale = standardize(train)
        coef = fit_ridge(scaled, target, alpha)
        held, _, _ = standardize([raw[hold]], mean, scale)
        pred = predict_row(coef, held[0])
        predictions.append(pred)
        errors.append(abs(pred - y[hold]))
    return sum(errors) / len(errors), predictions


def choose_alpha(raw, y):
    best = None
    for alpha in ALPHAS:
        mae, _ = loo_ridge(raw, y, alpha)
        if best is None or mae < best[0]:
            best = (mae, alpha)
    return best


def median(values):
    ordered = sorted(values)
    mid = len(ordered) // 2
    if len(ordered) % 2:
        return ordered[mid]
    return (ordered[mid - 1] + ordered[mid]) / 2.0


def enforce_ladder(levels):
    ordered = [max(0.0, levels[0])]
    for value in levels[1:]:
        ordered.append(max(ordered[-1], max(0.0, value)))
    return ordered


def submission_rows(case_ids, ladders, half_width):
    rows = []
    for case_id, ladder in zip(case_ids, ladders):
        point = ladder[0]
        row = {
            "case_id": case_id,
            "kd_cm1_1": f"{point:.4f}",
            "lower95_cm1": f"{max(0.0, point - half_width):.4f}",
            "upper95_cm1": f"{point + half_width:.4f}",
        }
        for index, value in enumerate(ladder[1:], start=2):
            row[f"kd_cm1_{index}"] = f"{value:.4f}"
        rows.append(row)
    return rows


def constant_rows(cases, support):
    ladders = [
        [median([float(row[f"kd_cm1_{level}"]) for row in support]) for level in LEVELS]
    ]
    low = min(float(row["kd_cm1_1"]) for row in support)
    high = max(float(row["kd_cm1_1"]) for row in support)
    point = ladders[0][0]
    rows = []
    for row in cases:
        item = {
            "case_id": row["case_id"],
            "kd_cm1_1": f"{point:.4f}",
            "lower95_cm1": f"{low:.4f}",
            "upper95_cm1": f"{high:.4f}",
        }
        for index, value in enumerate(ladders[0][1:], start=2):
            item[f"kd_cm1_{index}"] = f"{value:.4f}"
        rows.append(item)
    return rows


def g_trans_rows(cases, support):
    values = [float(row["g_trans"]) for row in support]
    targets = [float(row["kd_cm1_1"]) for row in support]
    loo = []
    for index, value in enumerate(values):
        best = min(
            (i for i in range(len(values)) if i != index),
            key=lambda i: (abs(values[i] - value), support[i]["case_id"]),
        )
        loo.append(abs(targets[best] - targets[index]))
    half = median(loo)
    rows = []
    for row in cases:
        value = float(row["g_trans"])
        best = min(
            range(len(values)),
            key=lambda i: (abs(values[i] - value), support[i]["case_id"]),
        )
        ladder = [float(support[best][f"kd_cm1_{level}"]) for level in LEVELS]
        point = ladder[0]
        item = {
            "case_id": row["case_id"],
            "kd_cm1_1": f"{point:.4f}",
            "lower95_cm1": f"{max(0.0, point - half):.4f}",
            "upper95_cm1": f"{point + half:.4f}",
        }
        for index, energy in enumerate(ladder[1:], start=2):
            item[f"kd_cm1_{index}"] = f"{energy:.4f}"
        rows.append(item)
    return rows, half


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", required=True, type=Path)
    args = parser.parse_args()
    support = read_rows(ROOT / "support.csv")
    cases = read_rows(ROOT / "cases.csv")
    support_x = [features(row["case_id"]) for row in support]
    test_ids = [row["case_id"] for row in cases]
    test_x = [features(key) for key in test_ids]
    support_ladders = [[float(row[f"kd_cm1_{level}"]) for level in LEVELS]
                        for row in support]
    test_by_level, half_width = [], None
    for index, target in enumerate(zip(*support_ladders)):
        _, alpha = choose_alpha(support_x, target)
        _, loo = loo_ridge(support_x, target, alpha)
        if index == 0:
            half_width = median([abs(a-b) for a,b in zip(loo, target)])
        scaled, center, scale = standardize(support_x)
        test, _, _ = standardize(test_x, center, scale)
        beta = fit_ridge(scaled, target, alpha)
        test_by_level.append([predict_row(beta, row) for row in test])
    ridge = submission_rows(test_ids, list(map(enforce_ladder, zip(*test_by_level))), half_width)
    g_rows, _ = g_trans_rows(cases, support)
    args.out_dir.mkdir(parents=True, exist_ok=True)
    examples = {
        "support_median": constant_rows(cases, support),
        "nearest_ground_g": g_rows,
        "geometry_ridge": ridge,
    }
    for name, rows in examples.items():
        with (args.out_dir / f"{name}.csv").open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)


if __name__ == "__main__":
    main()
