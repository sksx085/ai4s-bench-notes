#!/usr/bin/env python3
"""Validate a ladder prediction using only the public submission contract.

Usage: python3 check_submission.py predictions.csv [--cases cases.csv]

``read_validation(path, expected_ids)`` returns ``(report, parsed)``. A caller
must require report["status"] == "accepted" before scoring: parsed can contain
valid rows from an otherwise rejected file. No reference answers are read.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
import sys
from pathlib import Path

ENERGY_FIELDS = [f"kd_cm1_{i}" for i in range(1, 8)]
REQUIRED = ["case_id", "kd_cm1_1", "lower95_cm1", "upper95_cm1", *ENERGY_FIELDS[1:]]
NUMBER_FIELDS = [*ENERGY_FIELDS, "lower95_cm1", "upper95_cm1"]
ID_PATTERN = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:-]*\Z", re.ASCII)


def _valid_id(value):
    return isinstance(value, str) and ID_PATTERN.fullmatch(value) is not None


def _report(expected_ids):
    return {
        "status": "rejected",
        "n_expected": len(expected_ids),
        "n_rows": 0,
        "n_parsed": 0,
        "missing_ids": list(expected_ids),
        "problems": [],
    }


def read_validation(path, expected_ids):
    """Return deterministic format/domain errors and parsed valid CSV rows.

    Rows and columns may be permuted. The header must contain exactly REQUIRED
    once each; every expected ID must have exactly one valid row. Energies and
    interval endpoints must be finite, with 0 <= low <= E1 <= high and seven
    nonnegative, nondecreasing energies. There is no magnitude cap or tolerance.
    """
    try:
        expected = list(expected_ids)
    except TypeError:
        expected = []
    report = _report(expected)
    problems = report["problems"]
    parsed = {}
    if (
        not expected
        or any(not _valid_id(case_id) for case_id in expected)
        or len(set(expected)) != len(expected)
    ):
        problems.append({"problem": "invalid_expected_ids"})
        return report, parsed
    expected_set = set(expected)
    seen = set()
    try:
        with Path(path).open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.reader(handle, strict=True)
            header = next(reader, None)
            if header is None:
                problems.append({"line": 1, "problem": "missing_header"})
                return report, parsed
            duplicates = sorted({field for field in header if header.count(field) > 1})
            missing_fields = [field for field in REQUIRED if field not in header]
            extra_fields = [field for field in header if field not in REQUIRED]
            if duplicates:
                problems.append({"line": 1, "problem": "duplicate_header", "fields": duplicates})
            if missing_fields:
                problems.append({"line": 1, "problem": "missing_header_fields", "fields": missing_fields})
            if extra_fields:
                problems.append({"line": 1, "problem": "extra_header_fields", "fields": extra_fields})
            if problems:
                return report, parsed
            for cells in reader:
                line = reader.line_num
                report["n_rows"] += 1
                if len(cells) != len(header):
                    problems.append({
                        "line": line,
                        "problem": "wrong_cell_count",
                        "expected": len(header),
                        "actual": len(cells),
                    })
                    continue
                row = dict(zip(header, cells))
                case_id = row["case_id"]
                if not _valid_id(case_id):
                    problems.append({"line": line, "case_id": case_id, "problem": "invalid_id"})
                    continue
                if case_id in seen:
                    problems.append({"line": line, "case_id": case_id, "problem": "duplicate_id"})
                    continue
                seen.add(case_id)
                if case_id not in expected_set:
                    problems.append({"line": line, "case_id": case_id, "problem": "unknown_id"})
                    continue
                empty = [field for field in REQUIRED if not row[field].strip()]
                if empty:
                    problems.append({"line": line, "case_id": case_id, "problem": "missing_value", "fields": empty})
                    continue
                try:
                    values = [float(row[field]) for field in NUMBER_FIELDS]
                except (TypeError, ValueError, OverflowError):
                    problems.append({"line": line, "case_id": case_id, "problem": "non_numeric"})
                    continue
                if any(not math.isfinite(value) for value in values):
                    problems.append({"line": line, "case_id": case_id, "problem": "non_finite"})
                    continue
                energies, low, high = values[:7], values[7], values[8]
                if energies[0] < 0.0 or any(a > b for a, b in zip(energies, energies[1:])):
                    problems.append({"line": line, "case_id": case_id, "problem": "energy_not_ordered_or_negative"})
                    continue
                if not 0.0 <= low <= energies[0] <= high:
                    problems.append({"line": line, "case_id": case_id, "problem": "invalid_interval"})
                    continue
                parsed[case_id] = {"energies": energies, "low": low, "high": high}
    except (OSError, UnicodeError, TypeError, ValueError) as exc:
        problems.append({"problem": "input_file_error", "error_type": type(exc).__name__})
    except csv.Error:
        problems.append({"problem": "malformed_csv"})
    report["n_parsed"] = len(parsed)
    report["missing_ids"] = [case_id for case_id in expected if case_id not in parsed]
    report["status"] = "accepted" if not problems and not report["missing_ids"] else "rejected"
    return report, parsed


def _read_expected_ids(path):
    """Read public case IDs while allowing arbitrary metadata columns."""
    with Path(path).open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.reader(handle, strict=True)
        header = next(reader, [])
        if header.count("case_id") != 1 or len(set(header)) != len(header):
            raise ValueError("invalid cases header")
        index = header.index("case_id")
        ids = []
        for row in reader:
            if len(row) != len(header):
                raise ValueError("invalid cases row")
            ids.append(row[index])
    if not ids or any(not _valid_id(case_id) for case_id in ids) or len(set(ids)) != len(ids):
        raise ValueError("invalid cases IDs")
    return ids


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("submission")
    parser.add_argument("--cases", default=str(Path(__file__).with_name("cases.csv")))
    args = parser.parse_args(argv)
    try:
        expected = _read_expected_ids(args.cases)
    except (OSError, UnicodeError, ValueError, csv.Error) as exc:
        report = _report([])
        report["problems"].append({"problem": "cases_file_error", "error_type": type(exc).__name__})
    else:
        report, _ = read_validation(args.submission, expected)
    json.dump(report, sys.stdout, ensure_ascii=False, indent=2, allow_nan=False)
    sys.stdout.write("\n")
    return 0 if report["status"] == "accepted" else 2


if __name__ == "__main__":
    raise SystemExit(main())
