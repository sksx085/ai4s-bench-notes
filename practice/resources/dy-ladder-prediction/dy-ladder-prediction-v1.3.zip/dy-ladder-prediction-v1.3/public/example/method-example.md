## 输入列

这一行只使用 `support.csv` 里 SUP-01 的 `kd_cm1_1` 到 `kd_cm1_7`。没有使用测试分子。

## 程序入口

`python3 example/rescore_example.py example/prediction-example.csv`

## 适用边界

只复算公开样例的区间公式。不能外推到测试编号，也不能写成实测弛豫时间。
