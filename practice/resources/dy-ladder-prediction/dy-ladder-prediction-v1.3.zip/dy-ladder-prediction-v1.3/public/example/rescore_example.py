#!/usr/bin/env python3
"""Rescore the public SUP-01 example against support.csv.

This does not read the hidden test reference and does not score the DY test ids.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

EXAMPLE_ID = "SUP-01"
MISS_WEIGHT = 40.0
FIELDS = [
    "case_id",
    "kd_cm1_1",
    "lower95_cm1",
    "upper95_cm1",
    "kd_cm1_2",
    "kd_cm1_3",
    "kd_cm1_4",
    "kd_cm1_5",
    "kd_cm1_6",
    "kd_cm1_7",
]


def winkler(y, low, high):
    width = high - low
    if y < low:
        return width + MISS_WEIGHT * (low - y)
    if y > high:
        return width + MISS_WEIGHT * (y - high)
    return width


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("submission")
    args = parser.parse_args(argv)
    support_path = Path(__file__).resolve().parents[1] / "support.csv"
    with support_path.open(newline="") as handle:
        support = {row["case_id"]: row for row in csv.DictReader(handle)}
    if EXAMPLE_ID not in support:
        raise SystemExit(f"missing {EXAMPLE_ID} in {support_path}")
    with Path(args.submission).open(newline="") as handle:
        rows = list(csv.DictReader(handle))
    if len(rows) != 1 or rows[0].get("case_id") != EXAMPLE_ID:
        json.dump(
            {
                "status": "rejected",
                "reason": f"the example file must contain exactly one {EXAMPLE_ID} row",
                "counts_toward_test_score": False,
            },
            sys.stdout,
            ensure_ascii=False,
            indent=2,
        )
        sys.stdout.write("\n")
        return 2
    row = rows[0]
    try:
        point = float(row["kd_cm1_1"])
        low = float(row["lower95_cm1"])
        high = float(row["upper95_cm1"])
        energies = [point] + [float(row[f"kd_cm1_{i}"]) for i in range(2, 8)]
    except (KeyError, ValueError):
        json.dump({"status": "rejected", "reason": "non_numeric"}, sys.stdout, indent=2)
        sys.stdout.write("\n")
        return 2
    if any(not math.isfinite(v) for v in energies + [low, high]):
        json.dump({"status": "rejected", "reason": "non_finite"}, sys.stdout, indent=2)
        sys.stdout.write("\n")
        return 2
    if low > point or point > high or any(energies[i] > energies[i + 1] + 1e-6 for i in range(6)):
        json.dump({"status": "rejected", "reason": "interval_or_order"}, sys.stdout, indent=2)
        sys.stdout.write("\n")
        return 2
    truth = float(support[EXAMPLE_ID]["kd_cm1_1"])
    report = {
        "status": "example_only",
        "case_id": EXAMPLE_ID,
        "counts_toward_test_score": False,
        "reference_kd_cm1_1": truth,
        "abs_error_cm1": abs(point - truth),
        "winkler_cm1": winkler(truth, low, high),
        "covered": low <= truth <= high,
        "fields_checked": FIELDS,
    }
    json.dump(report, sys.stdout, ensure_ascii=False, indent=2)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
