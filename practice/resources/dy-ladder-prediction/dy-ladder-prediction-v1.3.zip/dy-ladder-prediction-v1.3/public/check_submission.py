#!/usr/bin/env python3
"""Check a ladder submission without reading hidden energies."""

from __future__ import annotations

import argparse
import csv
import io
import json
import math
import re
import sys
from pathlib import Path

ENERGY_FIELDS = [f"kd_cm1_{i}" for i in range(1, 8)]
REQUIRED = ["case_id", "kd_cm1_1", "lower95_cm1", "upper95_cm1", *ENERGY_FIELDS[1:]]
METHOD_HEADINGS = ("输入列", "程序入口", "适用边界")
MAX_FILE_BYTES = 1024 * 1024
HEADING = re.compile(r"^ {0,3}(#{1,6})[ \t]+(.+?)\s*$")
FENCE = re.compile(r"^ {0,3}(`{3,}|~{3,})(.*)$")


def read_submission_text(path: Path, name: str):
    """Decode a regular file, with an explicit bound on the amount read."""
    try:
        if not path.is_file():
            return None, {"problem": f"missing_{name}", "path": path.name}
        with path.open("rb") as handle:
            content = handle.read(MAX_FILE_BYTES + 1)
    except OSError:
        return None, {"problem": f"unreadable_{name}", "path": path.name}
    if len(content) > MAX_FILE_BYTES:
        return None, {"problem": f"{name}_too_large", "path": path.name}
    try:
        return content.decode("utf-8-sig"), None
    except UnicodeError:
        return None, {"problem": f"{name}_not_utf8", "path": path.name}


def method_problems(path: Path):
    text, problem = read_submission_text(path, "method_md")
    if problem:
        return [problem]

    sections = {}
    current = None
    fence = None
    for line in text.splitlines():
        fence_match = FENCE.match(line)
        if fence is not None:
            if (
                fence_match
                and fence_match.group(1).startswith(fence)
                and not fence_match.group(2).strip()
            ):
                fence = None
                continue
        elif fence_match:
            fence = fence_match.group(1)
            continue
        else:
            heading_match = HEADING.match(line)
            if heading_match:
                level, title = heading_match.groups()
                if len(level) <= 2:
                    title = re.sub(r"[ \t]+#+$", "", title)
                    current = title if len(level) == 2 and title in METHOD_HEADINGS else None
                    if current is not None:
                        sections.setdefault(current, False)
                continue

        if current is not None and line.strip():
            sections[current] = True

    problems = []
    for heading in METHOD_HEADINGS:
        if heading not in sections:
            problems.append({"problem": "missing_method_heading", "heading": heading})
        elif not sections[heading]:
            problems.append({"problem": "empty_method_section", "heading": heading})
    return problems


def parse_case(row):
    if any(row.get(field) in ("", None) for field in REQUIRED):
        return None, "missing_field"
    try:
        energies = [float(row[field]) for field in ENERGY_FIELDS]
        low = float(row["lower95_cm1"])
        high = float(row["upper95_cm1"])
    except (TypeError, ValueError, OverflowError):
        return None, "non_numeric"
    if any(not math.isfinite(value) for value in (*energies, low, high)):
        return None, "non_finite"
    if not low <= energies[0] <= high:
        return None, "interval_excludes_point"
    if energies[0] < 0 or any(first > second for first, second in zip(energies, energies[1:])):
        return None, "energy_not_ordered"
    if not math.isfinite(high - low):
        return None, "interval_width_overflow"
    return {"energies": energies, "low": low, "high": high}, None


def validate_rows(rows, expected):
    expected_ids = set(expected)
    parsed = {}
    problems = []
    seen = set()
    n_rows = 0
    for line, row in rows:
        n_rows += 1
        if row is None:
            problems.append({"line": line, "problem": "wrong_column_count"})
            continue
        case_id = row.get("case_id", "")
        if case_id not in expected_ids:
            problems.append({"line": line, "case_id": case_id, "problem": "unknown_id"})
            continue
        if case_id in seen:
            problems.append({"line": line, "case_id": case_id, "problem": "duplicate_id"})
            continue
        seen.add(case_id)
        item, problem = parse_case(row)
        if problem:
            problems.append({"line": line, "case_id": case_id, "problem": problem})
        else:
            parsed[case_id] = item

    return parsed, n_rows, problems


def csv_rows(reader):
    for fields in reader:
        if fields:
            row = dict(zip(REQUIRED, fields)) if len(fields) == len(REQUIRED) else None
            yield reader.line_num, row


def validate_submission(submission: Path, expected):
    method_path = submission.with_name("method.md")
    parsed, n_rows, problems = {}, 0, []
    text, problem = read_submission_text(submission, "predictions_csv")
    if problem:
        problems.append(problem)
    else:
        reader = csv.reader(io.StringIO(text, newline=""), strict=True)
        try:
            if next(reader, []) != REQUIRED:
                problems.append({"problem": "bad_header", "expected": REQUIRED})
            else:
                parsed, n_rows, problems = validate_rows(csv_rows(reader), expected)
        except csv.Error:
            problems.append({"line": reader.line_num, "problem": "malformed_csv"})

    missing = [case_id for case_id in expected if case_id not in parsed]
    problems.extend(method_problems(method_path))
    report = {
        "status": "accepted" if not problems and not missing else "rejected",
        "n_expected": len(expected),
        "n_rows": n_rows,
        "missing_ids": missing,
        "method": method_path.name,
        "problems": problems,
    }
    return report, parsed


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("submission", type=Path)
    parser.add_argument("--cases", type=Path, default=Path(__file__).with_name("cases.csv"))
    parser.add_argument("--method", type=Path, default=None)
    args = parser.parse_args(argv)
    if args.method and args.method.resolve() != args.submission.with_name("method.md").resolve():
        parser.error("method.md must be next to the submission")
    with args.cases.open(newline="", encoding="utf-8-sig") as handle:
        expected = [row["case_id"] for row in csv.DictReader(handle)]
    report, _ = validate_submission(args.submission, expected)
    json.dump(report, sys.stdout, ensure_ascii=False, indent=2, allow_nan=False)
    sys.stdout.write("\n")
    return 0 if report["status"] == "accepted" else 2


if __name__ == "__main__":
    raise SystemExit(main())
