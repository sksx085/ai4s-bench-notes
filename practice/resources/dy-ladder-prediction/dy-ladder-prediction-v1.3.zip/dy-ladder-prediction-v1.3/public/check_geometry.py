#!/usr/bin/env python3
"""Check the geometry-sheet submission without reading hidden gaps."""

from __future__ import annotations

import argparse
import csv
import io
import json
import math
import sys
from pathlib import Path

REQUIRED = ["case_id", "kd_cm1_1", "lower95_cm1", "upper95_cm1"]
MAX_FILE_BYTES = 1024 * 1024


def read_text(path: Path, name: str):
    try:
        if not path.is_file():
            return None, {"problem": f"missing_{name}", "path": path.name}
        with path.open("rb") as handle:
            content = handle.read(MAX_FILE_BYTES + 1)
    except OSError:
        return None, {"problem": f"unreadable_{name}", "path": path.name}
    if len(content) > MAX_FILE_BYTES:
        return None, {"problem": f"{name}_too_large", "path": path.name}
    try:
        return content.decode("utf-8-sig"), None
    except UnicodeError:
        return None, {"problem": f"{name}_not_utf8", "path": path.name}


def parse_case(row):
    if any(row.get(field) in ("", None) for field in REQUIRED):
        return None, "missing_field"
    try:
        point = float(row["kd_cm1_1"])
        low = float(row["lower95_cm1"])
        high = float(row["upper95_cm1"])
    except (TypeError, ValueError, OverflowError):
        return None, "non_numeric"
    if any(not math.isfinite(value) for value in (point, low, high)):
        return None, "non_finite"
    if point < 0:
        return None, "negative_gap"
    if not low <= point <= high:
        return None, "interval_excludes_point"
    if not math.isfinite(high - low):
        return None, "interval_width_overflow"
    return {"point": point, "low": low, "high": high}, None


def validate_geometry(submission: Path, cases: Path):
    with cases.open(newline="", encoding="utf-8-sig") as handle:
        expected = [row["case_id"] for row in csv.DictReader(handle)]
    problems = []
    parsed = {}
    text, problem = read_text(submission, "geometry_predictions_csv")
    n_rows = 0
    if problem:
        problems.append(problem)
    else:
        reader = csv.reader(io.StringIO(text, newline=""), strict=True)
        try:
            header = next(reader, [])
            if header != REQUIRED:
                problems.append({"problem": "bad_header", "expected": REQUIRED})
            else:
                seen = set()
                for row_fields in reader:
                    n_rows += 1
                    line = reader.line_num
                    if len(row_fields) != len(REQUIRED):
                        problems.append({"line": line, "problem": "wrong_column_count"})
                        continue
                    row = dict(zip(REQUIRED, row_fields))
                    case_id = row["case_id"]
                    if case_id not in expected:
                        problems.append({"line": line, "case_id": case_id, "problem": "unknown_id"})
                        continue
                    if case_id in seen:
                        problems.append({"line": line, "case_id": case_id, "problem": "duplicate_id"})
                        continue
                    seen.add(case_id)
                    item, item_problem = parse_case(row)
                    if item_problem:
                        problems.append({"line": line, "case_id": case_id, "problem": item_problem})
                    else:
                        parsed[case_id] = item
        except csv.Error:
            problems.append({"line": reader.line_num, "problem": "malformed_csv"})
    missing = [case_id for case_id in expected if case_id not in parsed]
    report = {
        "status": "accepted" if not problems and not missing else "rejected",
        "n_expected": len(expected),
        "n_rows": n_rows,
        "missing_ids": missing,
        "problems": problems,
    }
    return report, parsed


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("submission", type=Path)
    parser.add_argument("--cases", type=Path, default=Path(__file__).with_name("geometry-cases.csv"))
    args = parser.parse_args(argv)
    report, _parsed = validate_geometry(args.submission, args.cases)
    json.dump(report, sys.stdout, ensure_ascii=False, indent=2, allow_nan=False)
    sys.stdout.write("\n")
    return 0 if report["status"] == "accepted" else 2


if __name__ == "__main__":
    raise SystemExit(main())
