"""Public forward model for specular neutron reflectivity of a solvated film.

The stack is Si / SiO2 / polymer / liquid, viewed through the incident Si
substrate. Thicknesses and roughness use Å; SLDs use 10^-6 Å^-2. Reflectivity,
its uncertainty, and the additive instrument background are dimensionless.
The 3 Å interface roughness and 5% relative Q resolution are fixed modeling
assumptions from the refnx example rather than independent calibrations.
"""

import csv
import math

import numpy as np
from numpy.polynomial.hermite import hermgauss


SOLVENT_SLD = {"h2o": -0.56, "d2o": 6.36, "mix": 3.50}
BOUNDS = {
    "oxide_A": (1.0, 50.0),
    "polymer_A": (200.0, 300.0),
    "dry_sld": (0.1, 2.0),
    "fraction": (0.0, 1.0),
    "h2o_background": (9e-9, 3e-5),
    "d2o_background": (9e-9, 3e-5),
    "d2o_scale": (0.9, 1.1),
}
EFFECTIVE_SLD_BOUNDS = (-0.56, 2.0)
SILICON_SLD = 2.07
OXIDE_SLD = 3.47
ROUGHNESS_A = 3.0
RELATIVE_Q_FWHM = 0.05

_NODES, _WEIGHTS = hermgauss(12)
_GAUSSIAN_WEIGHTS = _WEIGHTS / math.sqrt(math.pi)
_Q_MULTIPLIERS = 1 + RELATIVE_Q_FWHM * _NODES / (2 * math.sqrt(math.log(2)))


def reflectivity(q, contrast, p):
    """Evaluate the smeared Parratt reflectivity at a one-dimensional Q grid.

    Use the H2O background and unit scale for the mixed-liquid prediction.
    D2O accepts its own background and scale after the readout. If omitted,
    these nuisance terms also use the H2O background and unit scale.
    """
    q = np.atleast_1d(np.asarray(q, dtype=float))
    if q.ndim != 1 or not np.all(np.isfinite(q)) or np.any(q <= 0):
        raise ValueError("Q must be a one-dimensional grid of finite positive values")

    solvent_sld = SOLVENT_SLD[contrast]
    fraction = p["fraction"]
    effective_sld = (1 - fraction) * p["dry_sld"] + fraction * solvent_sld
    sld_relative = (
        np.array([SILICON_SLD, OXIDE_SLD, effective_sld, solvent_sld]) - SILICON_SLD
    ) * 1e-6
    sampled_q = _Q_MULTIPLIERS[:, None] * q[None, :]
    # Complex wavevectors are needed below a critical edge.
    kz = np.sqrt((sampled_q[..., None] / 2) ** 2 - 4 * np.pi * sld_relative + 0j)
    incident, transmitted = kz[..., :-1], kz[..., 1:]
    interfaces = (incident - transmitted) / (incident + transmitted)
    interfaces *= np.exp(-2 * incident * transmitted * ROUGHNESS_A ** 2)

    amplitude = interfaces[..., 2]
    for index, thickness in ((1, p["polymer_A"]), (0, p["oxide_A"])):
        propagated = amplitude * np.exp(2j * transmitted[..., index] * thickness)
        interface = interfaces[..., index]
        amplitude = (interface + propagated) / (1 + interface * propagated)
    smeared = _GAUSSIAN_WEIGHTS @ np.abs(amplitude) ** 2

    background, scale = p["h2o_background"], 1.0
    if contrast == "d2o":
        background = p.get("d2o_background", background)
        scale = p.get("d2o_scale", scale)
    return scale * smeared + background


def fraction_limits(effective_sld):
    """Return all solvent fractions consistent with an H2O effective SLD."""
    effective_sld = float(effective_sld)
    if not EFFECTIVE_SLD_BOUNDS[0] <= effective_sld <= EFFECTIVE_SLD_BOUNDS[1]:
        raise ValueError("H2O effective SLD is outside the physical model bounds")
    lower_dry, upper_dry = BOUNDS["dry_sld"]
    h2o_sld = SOLVENT_SLD["h2o"]
    lower = max(0.0, (lower_dry - effective_sld) / (lower_dry - h2o_sld))
    upper = (upper_dry - effective_sld) / (upper_dry - h2o_sld)
    return lower, upper


def family_parameters(family, fraction):
    """Convert an H2O-equivalent family and a valid fraction to a structure."""
    effective_sld = float(family["effective_sld"])
    fraction = float(fraction)
    lower, upper = fraction_limits(effective_sld)
    if not lower - 1e-12 <= fraction <= upper + 1e-12:
        raise ValueError("solvent fraction is incompatible with the H2O effective SLD")
    fraction = min(upper, max(lower, fraction))
    if fraction == 1.0:
        # The layer has no dry material at this degenerate endpoint. The dry
        # SLD has no effect on any curve, so use the lower bound to represent it.
        dry_sld = BOUNDS["dry_sld"][0]
    else:
        dry_sld = (effective_sld - fraction * SOLVENT_SLD["h2o"]) / (1 - fraction)
        dry_sld = float(np.clip(dry_sld, *BOUNDS["dry_sld"]))
    return {
        "oxide_A": family["oxide_A"],
        "polymer_A": family["polymer_A"],
        "dry_sld": dry_sld,
        "fraction": fraction,
        "h2o_background": family["h2o_background"],
    }


def read_curve(path):
    """Read the released measured Q, R, and dR columns in file order."""
    with open(path, encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        columns = ("q_A_inv", "R", "dR")
        rows = [tuple(float(row[name]) for name in columns) for row in reader]
    if not rows:
        raise ValueError("curve has no measured rows")
    return tuple(np.asarray(rows, dtype=float).T)
