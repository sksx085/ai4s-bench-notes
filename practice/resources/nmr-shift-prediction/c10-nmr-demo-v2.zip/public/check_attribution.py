"""Validate the revised cases' peak IDs and optionally compare them with the author key."""

import argparse
import csv
import json
from pathlib import Path


FIELDS = ("case_id", "site_id", "h_peak", "c_peak")


def read(path, evidence):
    if not path.is_file() or path.stat().st_size > 65536:
        raise ValueError("请提供 64 KiB 以内的峰包归属表")
    keys = expected_keys(evidence)
    with path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream, strict=True)
        if tuple(reader.fieldnames or ()) != FIELDS:
            raise ValueError("峰包归属表头与模板不符")
        data = {}
        for row in reader:
            if None in row or None in row.values():
                raise ValueError("峰包归属列数不符")
            key = (row["case_id"], row["site_id"])
            if key not in keys or key in data:
                raise ValueError(f"重复或未知位点 {key}")
            allowed = evidence[key[0]]["candidates"]
            picks = (row["h_peak"], row["c_peak"])
            if any(pick not in {r["id"] for r in allowed[n]} for pick, n in zip(picks, ("1H", "13C"))):
                raise ValueError(f"未知峰号 {key}")
            data[key] = picks
    if set(data) != keys:
        raise ValueError("峰包归属表缺少位点")
    return data


def expected_keys(evidence):
    return {(case, site) for case, record in evidence.items() for site in record["target_sites"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--attributions", type=Path, required=True)
    parser.add_argument("--expected", type=Path)
    args = parser.parse_args()
    try:
        evidence = json.loads(args.evidence.read_text())
        data = read(args.attributions, evidence)
        out = {"status": "validated", "rows": len(data), "peak_ids": 2 * len(data)}
        if args.expected:
            key = read(args.expected, evidence)
            by_case = {
                case: {"hits": sum(got == expected for tag in key if tag[0] == case
                                   for got, expected in zip(data[tag], key[tag])), "total": 4}
                for case in evidence
            }
            out.update(status="scored", hits=sum(r["hits"] for r in by_case.values()), by_case=by_case)
        print(json.dumps(out, ensure_ascii=False, indent=2))
    except (ValueError, KeyError, OSError, csv.Error) as error:
        print(json.dumps({"status": "rejected", "reason": str(error)}, ensure_ascii=False))
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
