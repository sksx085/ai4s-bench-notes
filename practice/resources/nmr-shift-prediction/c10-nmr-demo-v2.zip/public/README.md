# C10 核磁位移预测 Demo v2

从 [题册](题册.html) 开始。D00 是公开的接口示例，T01–T10 是测试。T02、T03、T09 使用匿名位置、模拟的峰包杂波及稀释和二维相关证据，机器读数在 `test/evidence.json`。

- 用 `test/prediction-template.csv` 填 54 个数值。
- 用 `test/attribution-template.csv` 填三道变更题各位点的 H 峰号和 C 峰号。

格式检查只需 Python 3 标准库。把完成的文件放在当前目录，运行以下两个命令。

    python3 check.py --inputs test/inputs.jsonl --predictions prediction.csv
    python3 check_attribution.py --evidence test/evidence.json --attributions attribution.csv
