"""Validate NMR forecast keys and score a frozen reference locally."""
import argparse
import csv
import json
import re
from collections import defaultdict
from decimal import Decimal, InvalidOperation, localcontext
from pathlib import Path
from time import perf_counter


KEY = ("sample_id", "nucleus", "site_id")
PREDICTION = (*KEY, "point_ppm", "lower95_ppm", "upper95_ppm")
REFERENCE = (*KEY, "observed_ppm", "reported_decimals")
NUCLEI = ("1H", "13C")
SITE_METRICS = ("mae_ppm", "winkler95_ppm", "coverage95", "width95_ppm",
                "below_rate", "above_rate")
DIFFERENCE_METRICS = ("difference_mae_ppm", "direction_accuracy")
DECIMAL = re.compile(r"[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?")
ZERO = Decimal(0)


class SubmissionError(ValueError):
    """A format violation, distinct from a valid prediction's score."""


def load_manifest(path):
    return json.loads(path.read_text(encoding="utf-8"))


def expected_keys(manifest):
    return {
        (sample["sample_id"], site["nucleus"], site["site_id"])
        for sample in manifest["samples"] for site in sample["sites"]
    }


def read_table(path, columns):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.reader(stream, strict=True)
        if tuple(next(reader, [])) != columns:
            raise SubmissionError(f"expected header {','.join(columns)}")
        for row in reader:
            if len(row) != len(columns):
                raise SubmissionError(f"line {reader.line_num}: expected {len(columns)} fields")
            yield tuple(row[:3]), row[3:]


def decimal(raw, key):
    token = raw.strip()
    if len(token) > 200 or not DECIMAL.fullmatch(token):
        raise SubmissionError(f"{'/'.join(key)}: invalid decimal {raw!r}")
    try:
        value = Decimal(token)
    except InvalidOperation as error:
        raise SubmissionError(f"{'/'.join(key)}: invalid decimal {raw!r}") from error
    if not value.is_finite() or abs(value.adjusted()) > 1000:
        raise SubmissionError(f"{'/'.join(key)}: decimal exponent outside supported range")
    return value


def read_prediction(path, manifest):
    remaining = expected_keys(manifest)
    values = {}
    try:
        for key, row in read_table(path, PREDICTION):
            if key in values:
                raise SubmissionError(f"duplicate key {'/'.join(key)}")
            if key not in remaining:
                raise SubmissionError(f"unknown key {'/'.join(key)}")
            point, lower, upper = (decimal(token, key) for token in row)
            if not lower <= point <= upper:
                raise SubmissionError(f"{'/'.join(key)}: expected lower <= point <= upper")
            values[key] = (point, lower, upper)
            remaining.remove(key)
    except (OSError, UnicodeError, csv.Error) as error:
        raise SubmissionError(str(error)) from error
    if remaining:
        example = '/'.join(min(remaining))
        raise SubmissionError(f"{len(remaining)} missing keys, first {example}")
    return values


def read_reference(path, manifest):
    values = {}
    for key, (shift, precision) in read_table(path, REFERENCE):
        if key in values:
            raise ValueError(f"duplicate reference {key}")
        decimals = int(precision)
        if not 0 <= decimals <= 12:
            raise ValueError(f"incompatible precision for {key}")
        values[key] = (decimal(shift, key), Decimal(10) ** -decimals)
    if set(values) != expected_keys(manifest):
        raise ValueError("reference keys do not match the manifest")
    return values


def mean(values):
    return sum(values) / len(values) if values else None


def sign(value):
    return (value > 0) - (value < 0)


def summarize(rows, metrics):
    return {metric: mean([row[metric] for row in rows if row[metric] is not None])
            for metric in metrics}


def score(manifest, prediction, reference):
    sites, differences = [], []
    with localcontext() as context:
        context.prec = 2240
        for sample in manifest["samples"]:
            sample_id = sample["sample_id"]
            parent = sample["parent_id"]
            for site in sample["sites"]:
                nucleus, site_id = site["nucleus"], site["site_id"]
                key = sample_id, nucleus, site_id
                point, lower, upper = prediction[key]
                y, resolution = reference[key]
                width = upper - lower
                below, above = y < lower, y > upper
                sites.append(dict(
                    sample_id=sample_id, parent_id=parent, nucleus=nucleus, site_id=site_id,
                    observed_ppm=y, display_increment_ppm=resolution,
                    point_ppm=point, lower95_ppm=lower, upper95_ppm=upper,
                    signed_error_ppm=point - y, mae_ppm=abs(point - y),
                    winkler95_ppm=width + 40 * (max(lower - y, ZERO) + max(y - upper, ZERO)),
                    coverage95=int(not (below or above)), width95_ppm=width,
                    below_rate=int(below), above_rate=int(above),
                ))
            for comparison in sample["comparisons"]:
                nucleus = comparison["nucleus"]
                left = [(sample_id, nucleus, site_id) for site_id in comparison["left"]]
                right = [(sample_id, nucleus, site_id) for site_id in comparison["right"]]
                y = mean([reference[key][0] for key in right]) - mean([reference[key][0] for key in left])
                predicted = mean([prediction[key][0] for key in right]) - mean([prediction[key][0] for key in left])
                precision_bound = (mean([reference[key][1] for key in left])
                                   + mean([reference[key][1] for key in right])) / 2
                stable = abs(y) > precision_bound
                differences.append(dict(
                    sample_id=sample_id, parent_id=parent, nucleus=nucleus,
                    comparison_id=comparison["id"], left="+".join(comparison["left"]),
                    right="+".join(comparison["right"]), observed_difference_ppm=y,
                    predicted_difference_ppm=predicted, precision_bound_ppm=precision_bound,
                    observed_direction=sign(y) if stable else None, predicted_direction=sign(predicted),
                    difference_mae_ppm=abs(predicted - y),
                    direction_accuracy=int(sign(y) == sign(predicted)) if stable else None,
                ))
        by_parent = defaultdict(list)
        contrasts = defaultdict(list)
        for row in sites:
            by_parent[row["parent_id"], row["nucleus"]].append(row)
        for row in differences:
            contrasts[row["parent_id"], row["nucleus"]].append(row)
        parents = [
            dict(parent_id=parent, nucleus=nucleus, site_count=len(entries),
                 below_count=sum(row["below_rate"] for row in entries),
                 above_count=sum(row["above_rate"] for row in entries),
                 comparison_count=len(contrasts[parent, nucleus]),
                 direction_count=sum(row["direction_accuracy"] is not None for row in contrasts[parent, nucleus]),
                 **summarize(entries, SITE_METRICS),
                 **summarize(contrasts[parent, nucleus], DIFFERENCE_METRICS))
            for (parent, nucleus), entries in sorted(by_parent.items())
        ]
        metrics = {}
        count_metrics = ("site_count", "below_count", "above_count", "comparison_count", "direction_count")
        for nucleus in NUCLEI:
            rows = [row for row in parents if row["nucleus"] == nucleus]
            metrics[nucleus] = dict(
                parent_count=len(rows),
                direction_parent_count=sum(row["direction_count"] > 0 for row in rows),
                **{name: sum(row[name] for row in rows) for name in count_metrics},
                **summarize(rows, SITE_METRICS + DIFFERENCE_METRICS),
            )
    return sites, differences, parents, metrics


def write_csv(path, rows):
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def json_number(value):
    # Format ordinary scores as JSON numbers and preserve extreme finite scores.
    converted = float(value)
    if not (-float("inf") < converted < float("inf")) or (not converted and value):
        return str(value)
    return converted


def grade(manifest_path, prediction_path, reference_path, output):
    begin = perf_counter()
    manifest = load_manifest(manifest_path)
    output.mkdir(parents=True, exist_ok=False)
    try:
        prediction = read_prediction(prediction_path, manifest)
    except SubmissionError as error:
        result = {"status": "invalid_submission", "error": str(error)}
    else:
        sites, differences, parents, metrics = score(manifest, prediction, read_reference(reference_path, manifest))
        write_csv(output / "sites.csv", sites)
        write_csv(output / "differences.csv", differences)
        write_csv(output / "molecules.csv", parents)
        result = {"status": "scored", "metrics": metrics}
    (output / "metrics.json").write_text(json.dumps(result, default=json_number, indent=2) + "\n", encoding="utf-8")
    elapsed = perf_counter() - begin
    (output / "timing.json").write_text(json.dumps({"grade_elapsed_s": elapsed}, indent=2) + "\n", encoding="utf-8")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--predictions", required=True, type=Path)
    parser.add_argument("--reference", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.reference is None:
        read_prediction(args.predictions, load_manifest(args.manifest))
        print("valid submission")
    else:
        if args.output is None:
            parser.error("--reference requires --output")
        result = grade(args.manifest, args.predictions, args.reference, args.output)
        print(json.dumps(result, default=json_number, indent=2))
        return 0 if result["status"] == "scored" else 1
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SubmissionError as exc:
        raise SystemExit(f"invalid_submission: {exc}") from exc
