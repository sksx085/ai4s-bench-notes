"""Validate a prediction CSV, or score it when the corresponding reference is supplied."""

import argparse
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re
import sys


KEY = ("case_id", "group_id", "nucleus", "slot")
HEADER = (*KEY, "delta_ppm")
NUCLEI = ("1H", "13C")
NUMBER = re.compile(r"[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?\Z")
POINTS = {"location": 16, "contrast": 15, "direction": 8, "offset": 4, "joint_hit": 7}
SCALES = {"1H": ("0.25", "0.30", "0.03", "0.20", "0.12"),
          "13C": ("2.5", "2.8", "0.25", "2.0", "1.25")}


def read_jsonl(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def addresses(task):
    for group in task["groups"]:
        for slot in group["h_slots"]:
            yield task["id"], group["group_id"], "1H", slot
        yield task["id"], group["group_id"], "13C", "single"


def read_prediction(path, tasks):
    keys = {key for task in tasks for key in addresses(task)}
    if path.is_symlink() or not path.is_file():
        raise ValueError("prediction_missing")
    if path.stat().st_size > 64 * 1024:
        raise ValueError("prediction_too_large")
    with path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream, strict=True)
        if tuple(reader.fieldnames or ()) != HEADER:
            raise ValueError("header_mismatch")
        predictions = {}
        for row in reader:
            if None in row or None in row.values():
                raise ValueError("column_mismatch")
            key = tuple(row[k] for k in KEY)
            if key in predictions or key not in keys:
                raise ValueError(f"duplicate_or_unknown_key {key}")
            raw = row["delta_ppm"]
            if len(raw) > 64 or not NUMBER.fullmatch(raw):
                raise ValueError(f"invalid_number {key}")
            value = Decimal(raw)
            if not value.is_finite() or abs(value) > 1000:
                raise ValueError(f"invalid_number {key}")
            predictions[key] = value
    if keys != set(predictions):
        raise ValueError(f"missing_rows {len(keys - predictions.keys())}")
    for case, group, nucleus, slot in keys:
        if nucleus == "1H" and slot == "low":
            if predictions[(case, group, nucleus, "high")] < predictions[(case, group, nucleus, "low")]:
                raise ValueError(f"high_below_low {case} {group}")
    return predictions


def read_truth(path, tasks, fingerprint):
    truth = {}
    for entry in read_jsonl(path):
        if entry["inputs_sha256"] != fingerprint:
            raise ValueError("truth_input_mismatch")
        for row in entry["shifts"]:
            key = tuple(row[k] for k in KEY)
            if key in truth:
                raise ValueError(f"duplicate_truth {key}")
            truth[key] = Decimal(row["delta_ppm"])
    if set(truth) != {key for task in tasks for key in addresses(task)}:
        raise ValueError("truth_key_mismatch")
    return truth


def mean(items):
    values = list(items)
    return sum(values, Decimal(0)) / len(values)


def direction(gap, floor):
    return 1 if gap > floor else -1 if gap < -floor else 0


def credit(error, scale):
    return max(Decimal(0), 1 - abs(error) / scale)


def score(tasks, truth, predictions):
    scorecards, shift_rows, contrast_rows, splits = {}, [], [], []
    for task in tasks:
        case = task["id"]
        card = {}
        scorecards[case] = {"sample": task["sample"], "components": card}
        for nucleus in NUCLEI:
            scales = map(Decimal, SCALES[nucleus])
            location_scale, contrast_scale, floor, offset_scale, hit_limit = scales
            keys = [key for key in addresses(task) if key[2] == nucleus]
            residuals = {key: predictions[key] - truth[key] for key in keys}
            drifts, orders = [], []
            for first, second in task["contrasts"]:
                first_keys = [key for key in keys if key[1] == first]
                second_keys = [key for key in keys if key[1] == second]
                expected = mean(truth[k] for k in second_keys) - mean(truth[k] for k in first_keys)
                measured = mean(predictions[k] for k in second_keys) - mean(predictions[k] for k in first_keys)
                drifts.append(credit(measured - expected, contrast_scale))
                correct = int(direction(expected, floor) == direction(measured, floor))
                orders.append(correct)
                contrast_rows.append({
                    "case_id": case, "nucleus": nucleus, "contrast": f"{second}−{first}",
                    "reference_ppm": expected, "prediction_ppm": measured,
                    "abs_error_ppm": abs(measured - expected), "direction_correct": bool(correct),
                })
            card[nucleus] = {
                "location": mean(credit(e, location_scale) for e in residuals.values()),
                "contrast": mean(drifts), "direction": mean(orders),
                "offset": credit(mean(residuals.values()), offset_scale),
                "joint_hit": int(all(abs(e) <= hit_limit for e in residuals.values())),
            }
            for key in keys:
                shift_rows.append({**dict(zip(KEY, key)), "reference_ppm": truth[key],
                                   "prediction_ppm": predictions[key], "abs_error_ppm": abs(residuals[key])})
                if key[-1] == "low":
                    high = (*key[:-1], "high")
                    expected = truth[high] - truth[key]
                    measured = predictions[high] - predictions[key]
                    splits.append({"case_id": case, "group_id": key[1], "reference_ppm": expected,
                                   "prediction_ppm": measured, "abs_error_ppm": abs(measured - expected)})

    def total(dims):
        return sum(points * dims[n][metric] for n in NUCLEI for metric, points in POINTS.items())

    def combine(scores):
        return {n: {m: mean(card[n][m] for card in scores) for m in POINTS} for n in NUCLEI}

    macro = {}
    for sample in sorted({t["sample"] for t in tasks}):
        macro[sample] = combine([card["components"] for card in scorecards.values() if card["sample"] == sample])
    components = combine(list(macro.values()))
    for card in scorecards.values():
        card["points"] = total(card["components"])
    return {"status": "scored", "points": total(components), "components": components,
            "per_sample_points": {k: total(v) for k, v in macro.items()}, "per_case": scorecards,
            "site_errors": shift_rows, "contrast_errors": contrast_rows, "resolved_h_pair_errors": splits}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--expected", type=Path)
    options = parser.parse_args()
    try:
        tasks = read_jsonl(options.inputs)
        prediction = read_prediction(options.predictions, tasks)
        if options.expected:
            fingerprint = hashlib.sha256(options.inputs.read_bytes()).hexdigest()
            truth = read_truth(options.expected, tasks, fingerprint)
            output = score(tasks, truth, prediction)
        else:
            output = {"status": "validated", "cases": len(tasks), "rows": len(prediction)}
        print(json.dumps(output, ensure_ascii=False, default=float, indent=2, allow_nan=False))
    except (OSError, ValueError, KeyError, ArithmeticError, csv.Error) as error:
        print(json.dumps({"status": "rejected", "reason": str(error)}, ensure_ascii=False), file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
