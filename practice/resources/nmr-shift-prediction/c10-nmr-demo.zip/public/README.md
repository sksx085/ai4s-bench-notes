# C10 NMR Demo

打开 [离线 HTML 题册](题册.html) 或 [Markdown 题册](题册.md) 看结构图、实验条件、D00 的完整样例和 T01–T10。

- example/ 有样例输入、样品档案、公开答案和可直接运行的已填预测。
- test/ 有十道测试输入、三份共享样品档案和空白提交表。
- check.py 用 Python 3 标准库，可在本地直接运行。

从本目录运行公开样例，应得 100 分。

    python3 check.py --inputs example/inputs.jsonl --predictions example/prediction.csv --expected example/expected.jsonl

将 test/prediction-template.csv 另存并填好后，可检查十题格式。

    python3 check.py --inputs test/inputs.jsonl --predictions prediction.csv

D00 所用母分子独立。十道测试来自另外三个母分子，同一母分子下的题有相关性。C10 档案中的位移及归属为此 Demo 的参考。位移粗窗和评分阈值为题库制作参数。
