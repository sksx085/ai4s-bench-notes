# 镝配合物降场磁矩实验说明

八次实验使用同一份 31.5 mg 多晶 [Dy(Dtp)₂][Al{OC(CF₃)₃}₄]，用正二十烷固定。Quantum Design MPMS3 磁强计以振动样品模式（VSM）连续记录样品沿测量方向的磁矩，单位为 emu。仪器设定的信号平均时间为 0.5 秒，各点的实际采样时间以 CSV 为准。

每次到达设定温度后，在 +7 T 保持 30 分钟，再以 700 Oe/s 降场。仪器目标读数为 +22 Oe，用于补偿剩磁，样品处为校准后的近零场。两张 CSV 的 `nominal_temperature_K` 是实验设定温度。

以高场之后首个仪器场读数落入 22 ± 0.5 Oe 的采样点为 0 秒。这个范围用于定位数据起点。两张表保留 0 至 17,000 秒内实际存在的观测时刻，各实验使用自己的时间网格。`elapsed_time_s` 由原始时间戳相减得到。支持组的 `moment_emu` 保留原始 `Moment (emu)` 列的读数。

`support_curves.csv` 提供六次实验的时刻和磁矩。`test_times.csv` 提供 6 K 和 16 K 两次实验的时刻。两张表均使用 UTF-8，首行是列名。每行以 `run_id` 和 `point_id` 的组合唯一标识。

实验方法依据 Blackmore 等，*Characterisation of magnetic relaxation on extremely long timescales*，DOI `10.1039/D3CP01278F`。数据来自曼彻斯特大学 Figshare 归档 v2，DOI `10.48420/22203130.v2`，CC BY 4.0。题包只对原记录做时间重置、窗口截取和列选择。
